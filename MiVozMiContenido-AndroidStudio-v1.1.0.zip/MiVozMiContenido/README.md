# Mi Voz, Mi Contenido — Android MVP

Proyecto nativo Android (Kotlin + Jetpack Compose) para abrir en Android Studio.

## Incluido en esta primera versión
- Editor de monólogos y guiones con modos **Texto exacto** y **Modo creador**.
- Selector de duración y plataforma.
- Guardado local de guiones.
- Grabación AAC/M4A con micrófono, reproducción, detención y eliminación.
- Almacenamiento privado de la app; no se suben audios a la nube.
- Pantalla de consentimiento y confirmación de mayoría de edad como puerta de control para una futura función de clonación.

## Abrir y ejecutar
1. Instala Android Studio estable y Android SDK Platform 35.
2. Abre la carpeta `MiVozMiContenido` en Android Studio.
3. Acepta la sincronización de Gradle (JDK 17).
4. Conecta el Pixel 9 Pro con depuración USB o inicia un emulador API 35.
5. Ejecuta la configuración `app` y concede permiso de micrófono cuando Android lo solicite.

No se incluye Gradle Wrapper porque no hay una distribución de Gradle verificada en el entorno de empaquetado. Android Studio puede generar/usar el wrapper desde su instalación local.

## Módulo de voz sintética local: evaluación y decisión

**Estado real de esta entrega: no integrado ni activado.** No sería correcto afirmar que clona tu voz, que corre en el Pixel o que se probó en ese dispositivo. La interfaz incorpora los controles de edad/consentimiento, pero no produce voz sintética.

### Candidato para una fase de investigación
- **OpenVoice V2** es un candidato de investigación por su enfoque de clonación de voz y licencia de código MIT publicada en su repositorio oficial. La licencia MIT del código no sustituye la revisión de licencias de pesos, modelos auxiliares, voces, datasets y dependencias.
- Su ruta de inferencia publicada está orientada principalmente a Python/PyTorch; no equivale a un runtime Android listo para producción. Antes de adoptarlo hay que comprobar exportabilidad de cada submodelo, operadores soportados, cuantización, latencia y calidad en español.
- Alternativa para un MVP de TTS sin clonación: motores TTS locales empaquetados con ONNX Runtime Mobile o Android TTS. Eso no satisface la réplica de identidad vocal.

### Arquitectura recomendada
`VoiceCloneEngine` como interfaz Kotlin, con implementaciones intercambiables: `UnavailableVoiceCloneEngine` (actual), y posteriormente `OnnxVoiceCloneEngine` si se consigue un pipeline exportable y licenciado. Mantener el modelo descargable por separado del APK, verificar SHA-256, mostrar tamaño/licencia, permitir borrado completo y no enviar muestras fuera del dispositivo.

### Presupuesto de recursos para Pixel 9 Pro
El Pixel 9 Pro usa Tensor G4 y 16 GB de RAM según la ficha de Google. Eso no garantiza que un modelo PyTorch concreto funcione en Android. Reservar una fase de medición con memoria pico, latencia por segundo de audio, calentamiento, temperatura y consumo de batería. Para un prototipo ONNX cuantizado, planificar inicialmente varios cientos de MB hasta >1 GB según arquitectura y pesos; el tamaño real debe salir del artefacto elegido, no de una estimación.

### Condiciones antes de habilitar clonación
1. Verificar que las muestras sean exclusivamente de la voz del usuario o exista autorización explícita y documentada del titular.
2. Confirmación de mayoría de edad y consentimiento informado, revocable.
3. Revisar por separado licencia del código, pesos, componentes auxiliares y restricciones comerciales.
4. Probar en el Pixel físico: instalación limpia, generación offline, memoria, latencia, calidad en español, temperatura y estabilidad.
5. Etiquetar la salida como voz sintética y conservar registro local de consentimiento/modelo usado.

## Limitaciones conocidas
- La versión inicial no sincroniza entre dispositivos.
- Los guiones se guardan como archivos de texto en el almacenamiento privado de la app; no hay aún biblioteca avanzada, exportación ni sincronización.
- La grabación requiere permiso de micrófono.
- No se ha compilado ni ejecutado en un Pixel 9 Pro desde este entorno. El APK no se adjunta porque no hay Android SDK/Gradle disponibles aquí para producir un binario verificable.


## Novedades de la versión 1.1.0
- Perfil de voz con cinco frases guiadas para grabar muestras propias.
- Bloqueo de captura del perfil hasta confirmar mayoría de edad y consentimiento.
- Indicador de avance, opción de volver a grabar y eliminación de cada muestra.
- Las muestras permanecen en el almacenamiento privado del dispositivo.

La clonación sintética sigue pendiente de un motor móvil validado. Las casillas son autodeclaraciones y no verifican identidad o edad. Consulta `VOICE_MODEL_NOTES.md` para la evaluación técnica actualizada.
