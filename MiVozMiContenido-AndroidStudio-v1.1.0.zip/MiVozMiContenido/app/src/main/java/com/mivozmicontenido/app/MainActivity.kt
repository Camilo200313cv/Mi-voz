package com.mivozmicontenido.app

import android.Manifest
import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { AppScreen(this) } } }
}

data class VoiceTake(val name: String, val path: String, val created: Long)

@Composable
fun AppScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("mivoz", Context.MODE_PRIVATE) }
    var title by remember { mutableStateOf("") }
    var script by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Texto exacto") }
    var duration by remember { mutableStateOf("60 segundos") }
    var platform by remember { mutableStateOf("Instagram Reels") }
    var status by remember { mutableStateOf("Tus guiones y audios se guardan en este dispositivo.") }
    var takes by remember { mutableStateOf(loadTakes(context)) }
    var profileSamples by remember { mutableStateOf(loadProfileSamples(context)) }
    var activeSample by remember { mutableStateOf<String?>(null) }
    var recorder: MediaRecorder? by remember { mutableStateOf(null) }
    var player: MediaPlayer? by remember { mutableStateOf(null) }
    var recording by remember { mutableStateOf(false) }
    var consent by remember { mutableStateOf(prefs.getBoolean("voice_consent", false)) }
    var ageConfirmed by remember { mutableStateOf(prefs.getBoolean("age_confirmed", false)) }
    val requestPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) status = "Permiso concedido. Pulsa Grabar para iniciar." else status = "Necesitas conceder permiso de micrófono para grabar."
    }

    fun saveScript() {
        val safeTitle = title.ifBlank { "Guion sin título" }
        val folder = File(context.filesDir, "scripts").apply { mkdirs() }
        val file = File(folder, "${System.currentTimeMillis()}.txt")
        file.writeText("$safeTitle\nModo: $mode\nDuración: $duration\nPlataforma: $platform\n\n$script")
        status = "Guion guardado localmente: ${file.name}"
    }

    fun startRecording(sampleIndex: Int? = null) {
        try {
            val folder = File(context.filesDir, if (sampleIndex == null) "recordings" else "voice_profile").apply { mkdirs() }
            val prefix = if (sampleIndex == null) "voz" else "muestra_${sampleIndex + 1}"
            val output = File(folder, "${prefix}_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(output.absolutePath)
            r.prepare(); r.start(); recorder = r; recording = true; activeSample = sampleIndex?.toString()
            status = if (sampleIndex == null) "Grabando tu voz…" else "Grabando muestra ${sampleIndex + 1} de tu perfil de voz…"
        } catch (e: Exception) { status = "No se pudo iniciar la grabación: ${e.localizedMessage}" }
    }
    fun stopRecording() {
        try {
            recorder?.stop(); recorder?.release(); recorder = null; recording = false
            takes = loadTakes(context); profileSamples = loadProfileSamples(context); status = "Grabación guardada en el almacenamiento privado de la app."; activeSample = null
        } catch (e: Exception) { status = "La grabación fue demasiado corta o falló: ${e.localizedMessage}"; recording = false; recorder?.release(); recorder = null; activeSample = null }
    }

    Scaffold { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Mi Voz, Mi Contenido", style = MaterialTheme.typography.headlineMedium)
            Text("Tu taller local de guiones, monólogos y voz.", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título del monólogo o guion") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = mode == "Texto exacto", onClick = { mode = "Texto exacto" }, label = { Text("Texto exacto") })
                FilterChip(selected = mode == "Modo creador", onClick = { mode = "Modo creador" }, label = { Text("Modo creador") })
            }
            Text(if (mode == "Texto exacto") "Conserva tus palabras tal como las escribiste." else "Espacio para trabajar ritmo, remates, pausas y adaptación a cámara.")
            OutlinedTextField(value = script, onValueChange = { script = it }, label = { Text("Escribe aquí tu texto…") }, modifier = Modifier.fillMaxWidth().height(220.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { Text("Duración"); DropdownChoice(duration, listOf("15 segundos", "30 segundos", "60 segundos", "90 segundos", "3 minutos", "5 minutos")) { duration = it } }
                Column(Modifier.weight(1f)) { Text("Plataforma"); DropdownChoice(platform, listOf("Instagram Reels", "TikTok", "YouTube Shorts", "YouTube", "Facebook")) { platform = it } }
            }
            Button(onClick = { saveScript() }, modifier = Modifier.fillMaxWidth()) { Text("Guardar guion") }
            HorizontalDivider()
            Text("Grabación de tu voz", style = MaterialTheme.typography.titleLarge)
            Text("Los audios se guardan localmente; no se envían a ningún servidor.")
            Button(onClick = {
                if (recording) stopRecording() else {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                    else requestPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (recording) "Detener y guardar" else "Grabar mi narración") }
            Text("Grabaciones", style = MaterialTheme.typography.titleMedium)
            if (takes.isEmpty()) Text("Todavía no tienes grabaciones.")
            takes.forEach { take ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(take.name)
                        Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(take.created)), style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                try { player?.release(); player = MediaPlayer().apply { setDataSource(take.path); prepare(); start() }; status = "Reproduciendo ${take.name}" } catch (e: Exception) { status = "No se pudo reproducir: ${e.localizedMessage}" }
                            }) { Text("Reproducir") }
                            OutlinedButton(onClick = { player?.stop(); player?.release(); player = null; status = "Reproducción detenida." }) { Text("Detener") }
                            OutlinedButton(onClick = { player?.release(); player = null; File(take.path).delete(); takes = loadTakes(context); status = "Grabación eliminada." }) { Text("Eliminar") }
                        }
                    }
                }
            }
            HorizontalDivider()
            Row { Checkbox(checked = ageConfirmed, onCheckedChange = { ageConfirmed = it; prefs.edit().putBoolean("age_confirmed", it).apply() }); Text("Confirmo que soy mayor de 18 años.", modifier = Modifier.padding(top = 12.dp)) }
            Row { Checkbox(checked = consent, onCheckedChange = { consent = it; prefs.edit().putBoolean("voice_consent", it).apply() }); Text("Autorizo el uso de mis propias grabaciones para crear una réplica sintética de mi voz.", modifier = Modifier.padding(top = 12.dp)) }
            Button(onClick = { status = if (ageConfirmed && consent) "Consentimiento registrado localmente. La generación seguirá bloqueada hasta integrar y validar el modelo." else "Confirma mayoría de edad y consentimiento para continuar." }, enabled = ageConfirmed && consent, modifier = Modifier.fillMaxWidth()) { Text("Guardar consentimiento") }
            Text("Perfil de voz — preparación de muestras", style = MaterialTheme.typography.titleLarge)
            Text("Antes de grabar, confirma abajo que eres mayor de edad y que autorizas el uso de tu propia voz. Después graba cinco frases cortas en un lugar silencioso, con tu voz natural y sin música. Las muestras quedan privadas en el dispositivo; todavía no entrenan ni activan una voz sintética.")
            val prompts = listOf(
                "Hola, soy yo. Esta es una muestra de mi voz hablando de manera tranquila y natural.",
                "Cuando cuento una historia, cambio el ritmo, hago pausas y remarco las palabras importantes.",
                "A veces hablo rápido, otras veces bajo la voz para preparar un remate inesperado.",
                "En Colombia tenemos muchas formas de decir lo mismo, y cada región tiene su propio ritmo.",
                "Esta última frase la voy a decir con energía, claridad y una sonrisa en la voz."
            )
            val completed = (0..4).count { index -> profileSamples.any { it.name.startsWith("muestra_${index + 1}_") } }
            Text("Muestras guardadas: $completed de 5", style = MaterialTheme.typography.titleMedium)
            LinearProgressIndicator(progress = { completed / 5f }, modifier = Modifier.fillMaxWidth())
            prompts.forEachIndexed { index, prompt ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Muestra ${index + 1}", style = MaterialTheme.typography.titleSmall)
                        Text(prompt)
                        val saved = profileSamples.filter { it.name.startsWith("muestra_${index + 1}_") }.maxByOrNull { it.created }
                        Text(if (saved == null) "Pendiente" else "Grabada · ${SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(saved.created))}", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            if (recording) stopRecording() else {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording(index)
                                else requestPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }, enabled = ageConfirmed && consent && (!recording || activeSample == index.toString()), modifier = Modifier.fillMaxWidth()) {
                            Text(if (recording && activeSample == index.toString()) "Detener y guardar muestra" else if (saved == null) "Grabar esta frase" else "Volver a grabar esta frase")
                        }
                        if (saved != null && !recording) {
                            OutlinedButton(onClick = { File(saved.path).delete(); profileSamples = loadProfileSamples(context); status = "Muestra eliminada del perfil de voz." }, modifier = Modifier.fillMaxWidth()) { Text("Eliminar esta muestra") }
                        }
                    }
                }
            }
            Text("Voz sintética local — integración pendiente", style = MaterialTheme.typography.titleLarge)
            Text("La clonación sigue bloqueada. Primero se recopilan muestras propias; después se integrará un motor móvil con licencia verificada, funcionamiento sin conexión y pruebas reales de rendimiento en el teléfono. No se sube audio a servidores.")
            Text(status, color = MaterialTheme.colorScheme.primary)
            Text("Privacidad: los archivos se almacenan en el espacio privado de la app. Desinstalarla elimina esos datos.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun DropdownChoice(value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(value) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false }) }
        }
    }
}

fun loadProfileSamples(context: Context): List<VoiceTake> {
    val folder = File(context.filesDir, "voice_profile")
    return folder.listFiles()?.filter { it.isFile && it.extension == "m4a" }?.sortedByDescending { it.lastModified() }?.map { VoiceTake(it.name, it.absolutePath, it.lastModified()) } ?: emptyList()
}

fun loadTakes(context: Context): List<VoiceTake> {
    val folder = File(context.filesDir, "recordings")
    return folder.listFiles()?.filter { it.isFile && it.extension == "m4a" }?.sortedByDescending { it.lastModified() }?.map { VoiceTake(it.name, it.absolutePath, it.lastModified()) } ?: emptyList()
}
