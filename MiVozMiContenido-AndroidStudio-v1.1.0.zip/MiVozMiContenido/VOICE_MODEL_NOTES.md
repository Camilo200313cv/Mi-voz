# Fase 2: perfil de voz y evaluación del motor local

## Lo que incorpora esta versión
- Captura guiada de cinco frases en español, pensadas para recoger voz conversacional, ritmo, pausas y entonación.
- Las muestras se guardan en `filesDir/voice_profile`, dentro del almacenamiento privado de la app.
- La captura de muestras para el perfil está bloqueada hasta que el usuario marque mayoría de edad y consentimiento explícito para usar su propia voz.
- Se pueden volver a grabar y eliminar muestras. La app no envía los audios a un servidor.
- El consentimiento es una autodeclaración local: **no equivale a una verificación de identidad o edad**.

## Evaluación de modelos

### OpenVoice V2 — candidato de investigación para clonación
El repositorio oficial declara soporte multilingüe nativo, incluido español, y licencia MIT para V1/V2. Es prometedor para preservar color de voz y controlar estilo, ritmo y pausas. Sin embargo, el proyecto de referencia no constituye por sí mismo un paquete Android listo para integrar. Antes de distribuir pesos o dependencias se debe revisar la licencia y procedencia de cada artefacto concreto, no solo la licencia del repositorio. Referencia: https://github.com/myshell-ai/OpenVoice

### sherpa-onnx — candidato de runtime Android
sherpa-onnx documenta ejecución local en Android/ARM64 y dispone de ejemplos y APKs de TTS. Es una base razonable para evaluar inferencia ONNX en el dispositivo, pero su soporte general de TTS no demuestra que cualquier pipeline de clonación de voz pueda ejecutarse directamente en él. La compatibilidad de OpenVoice V2 con ese runtime requiere conversión, adaptación de operadores y pruebas específicas. Referencias: https://github.com/k2-fsa/sherpa-onnx y https://k2-fsa.github.io/sherpa/onnx/tts/apk.html

## Próximo trabajo técnico necesario
1. Elegir una arquitectura concreta de clonación compatible con Android y español; no confundir TTS genérico con clonación de identidad vocal.
2. Exportar cada etapa a ONNX (si es viable), comprobar operadores y fijar versiones de runtime.
3. Descargar los modelos por separado del APK, desde una fuente autenticada, con hash SHA-256 y licencias visibles.
4. Implementar `VoiceCloneEngine` con estados `NotInstalled`, `NeedsConsent`, `Ready`, `Generating` y `Failed`.
5. Mantener todo offline después de descargar los modelos; incluir borrado de perfil, muestras y embeddings.
6. Medir en un Pixel 9 Pro real RAM pico, tiempo de generación, temperatura, batería, estabilidad y naturalidad del español colombiano.

## Criterios para declarar la función lista
- Genera audio a partir de texto usando únicamente las muestras del propio usuario.
- Funciona sin conexión después de instalar los modelos.
- Se ha verificado la licencia de código, pesos, modelos auxiliares y dependencias.
- Consentimiento revocable y eliminación verificable de datos.
- Pruebas reproducibles en dispositivo físico; no basta con compilar.

**Estado actual:** perfil de muestras guiado implementado en el código fuente. La generación sintética sigue desactivada; no se afirma que exista clonación funcional ni se ha producido un APK probado.
