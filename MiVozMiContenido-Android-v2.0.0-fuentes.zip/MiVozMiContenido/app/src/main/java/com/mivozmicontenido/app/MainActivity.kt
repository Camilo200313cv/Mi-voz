package com.mivozmicontenido.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF25213A)
private val Purple = Color(0xFF6B4EFF)
private val Canvas = Color(0xFFF7F5F2)
private data class Script(val id: Long, val title: String, val body: String, val updated: Long)
private data class AudioItem(val name: String, val path: String, val created: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MiVozApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MiVozApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mi_voz_v2", Context.MODE_PRIVATE) }
    var scripts by remember { mutableStateOf(loadScripts(prefs)) }
    var audios by remember { mutableStateOf(loadAudios(context)) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) message = "Permiso concedido. Pulsa Grabar otra vez." else message = "Necesitas permitir el micrófono para grabar."
    }
    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) { ttsReady = true; tts?.language = Locale("es", "CO") } }
        tts = engine
        onDispose { runCatching { recorder?.release() }; runCatching { player?.release() }; engine.shutdown() }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Canvas, surface = Color.White, onBackground = Ink, onSurface = Ink)) {
        Scaffold(containerColor = Canvas, topBar = { TopAppBar(title = { Column { Text("Mi Voz, Mi Contenido", fontWeight = FontWeight.Bold); Text("Tu espacio creativo", style = MaterialTheme.typography.labelMedium, color = Color.Gray) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Canvas)) },
            bottomBar = { NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.EditNote, null) }, label = { Text("Guiones") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Mic, null) }, label = { Text("Audios") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.RecordVoiceOver, null) }, label = { Text("Mi voz") })
            } }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(10.dp))
                when (selectedTab) {
                    0 -> {
                        Text("Escribe y guarda tus ideas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título del guion") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(16.dp))
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Escribe aquí tu rutina, idea o texto...") }, modifier = Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(min = 170.dp, max = 290.dp), shape = RoundedCornerShape(16.dp))
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (body.isBlank()) message = "Escribe algo antes de guardar."
                                else {
                                    val now = System.currentTimeMillis(); val cleanTitle = title.ifBlank { "Guion ${scripts.size + 1}" }
                                    val updated = listOf(Script(now, cleanTitle, body.trim(), now)) + scripts
                                    scripts = updated; saveScripts(prefs, updated); title = ""; body = ""; message = "Guion guardado correctamente."
                                }
                            }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text("Guardar guion") }
                            OutlinedButton(onClick = { if (body.isBlank()) message = "Escribe un texto primero." else if (ttsReady) { tts?.language = Locale("es", "CO"); tts?.speak(body, TextToSpeech.QUEUE_FLUSH, null, "preview") ; message = "Leyendo con la voz disponible en tu teléfono." } else message = "La voz del teléfono todavía está iniciando." }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(4.dp)); Text("Escuchar") }
                        }
                        if (message.isNotBlank()) Text(message, color = Purple, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
                        Text("Tus guiones", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(scripts, key = { it.id }) { script ->
                                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f).clickable { title = script.title; body = script.body; message = "Guion cargado para editar." }) {
                                            Text(script.title, fontWeight = FontWeight.SemiBold)
                                            Text(script.body, maxLines = 2, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }
                                        IconButton(onClick = { scripts = scripts.filterNot { it.id == script.id }; saveScripts(prefs, scripts); message = "Guion eliminado." }) { Icon(Icons.Default.DeleteOutline, "Eliminar guion") }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        Text("Biblioteca de audios", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Graba tus ideas y vuelve a escucharlas cuando quieras.", color = Color.Gray, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            if (!granted) permission.launch(Manifest.permission.RECORD_AUDIO)
                            else if (!recording) {
                                try {
                                    val file = File(context.filesDir, "audio_${System.currentTimeMillis()}.m4a")
                                    val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
                                    r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setOutputFile(file.absolutePath); r.prepare(); r.start(); recorder = r; recording = true; message = "Grabando… pulsa Detener al terminar."
                                } catch (e: Exception) { message = "No se pudo iniciar la grabación: ${e.localizedMessage}" }
                            } else {
                                try { recorder?.stop(); recorder?.release(); recorder = null; recording = false; audios = loadAudios(context); message = "Grabación guardada." } catch (e: Exception) { recording = false; message = "La grabación fue demasiado corta o falló."; runCatching { recorder?.release() }; recorder = null }
                            }
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (recording) Color(0xFFB3261E) else Purple)) { Icon(if (recording) Icons.Default.Stop else Icons.Default.FiberManualRecord, null); Spacer(Modifier.width(8.dp)); Text(if (recording) "Detener y guardar" else "Grabar audio") }
                        if (message.isNotBlank()) Text(message, color = Purple, modifier = Modifier.padding(vertical = 10.dp), style = MaterialTheme.typography.bodySmall)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(audios, key = { it.path }) { audio ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.GraphicEq, null, tint = Purple); Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) { Text(audio.name, fontWeight = FontWeight.Medium); Text(SimpleDateFormat("dd/MM/yyyy · HH:mm", Locale.getDefault()).format(Date(audio.created)), style = MaterialTheme.typography.labelSmall, color = Color.Gray) }
                                        IconButton(onClick = { runCatching { player?.release(); player = MediaPlayer().apply { setDataSource(audio.path); prepare(); start() } }.onFailure { message = "No se pudo reproducir este audio." } }) { Icon(Icons.Default.PlayArrow, "Reproducir") }
                                        IconButton(onClick = { runCatching { File(audio.path).delete() }; audios = loadAudios(context); message = "Audio eliminado." }) { Icon(Icons.Default.DeleteOutline, "Eliminar") }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("Mi voz", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Icon(Icons.Default.RecordVoiceOver, null, tint = Purple, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(8.dp)); Text("Voz del dispositivo", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("Puedes escuchar tus textos con el motor de voz que tenga instalado Android. Esta función es gratuita y no envía tu texto a un servidor.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                                Spacer(Modifier.height(12.dp)); Text("Clonación de voz", fontWeight = FontWeight.Bold)
                                Text("No está activada en esta versión. No voy a presentarte una voz sintética genérica como si fuera tu clon. La clonación real requiere un motor compatible y revisar sus condiciones de uso y privacidad antes de integrar cualquier servicio.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                                Spacer(Modifier.height(12.dp)); Text("Tus grabaciones permanecen en el almacenamiento privado de la aplicación.", style = MaterialTheme.typography.labelMedium, color = Purple)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun saveScripts(prefs: android.content.SharedPreferences, scripts: List<Script>) {
    val array = JSONArray(); scripts.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updated", it.updated)) }
    prefs.edit().putString("scripts", array.toString()).apply()
}
private fun loadScripts(prefs: android.content.SharedPreferences): List<Script> = runCatching {
    val a = JSONArray(prefs.getString("scripts", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); Script(o.getLong("id"), o.getString("title"), o.getString("body"), o.optLong("updated")) }
}.getOrDefault(emptyList())
private fun loadAudios(context: Context): List<AudioItem> = context.filesDir.listFiles()?.filter { it.isFile && it.name.startsWith("audio_") && it.extension == "m4a" }?.map { AudioItem(it.nameWithoutExtension, it.absolutePath, it.lastModified()) }?.sortedByDescending { it.created } ?: emptyList()
