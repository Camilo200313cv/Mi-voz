# Mi Voz, Mi Contenido 2.0

Proyecto Android nativo en Kotlin + Jetpack Compose. Incluye editor y persistencia local de guiones, biblioteca privada de grabaciones, reproducción/eliminación y lectura de texto mediante Android TextToSpeech.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK 35

## Construir
Abre esta carpeta desde Android Studio y ejecuta `assembleDebug` o usa `gradle assembleDebug` con Gradle 8.9.

## Alcance y privacidad
- Los guiones se guardan en SharedPreferences locales.
- Los audios se guardan en el directorio privado de la app; no se suben.
- La lectura usa el motor TTS instalado en Android.
- La clonación real de voz no está integrada en esta entrega. No se simula ni se presenta TTS genérico como clonación.
- No hay claves API, cuentas pagas ni servicios externos configurados.

El workflow `.github/workflows/android.yml` permite compilar el APK con GitHub Actions en un repositorio con Actions habilitado.
